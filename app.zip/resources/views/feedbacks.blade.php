@extends('layouts.map-layout')
@section('content')
   <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                  
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
     
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                  
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i> 
                                
                                        <span class="caption-subject bold uppercase">Feedbacks</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                  
                                     <p class="successresponce"></p>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Username</th>						
                        						<th>Feedback</th>
                        						<th>Date</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; ?> 
                                            @foreach($feedbacks as $feedback)
                                             <tr>
                                                <td>{{++$i}}</td>
                                                <td><a href="#">{{$feedback->username}}</a></td>
                                                <td>{{$feedback->feedback}}</td>         
                                                 <td>{{date('d-m-Y',strtotime($feedback->created_at))}}</td>   
                                               
                        					 
                                            </tr>
                        				 @endforeach
                                        </tbody>
                                    </table>
                                    
                                 
                                </div>
                            </div>
                           
                        </div>
                    </div>
                 </div>
                <!-- END CONTENT BODY -->
            </div>
           
  @endsection
  
