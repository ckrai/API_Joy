@extends('layouts.map-layout')
@section('content')
  <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                   
               
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Dashboard
                     </h3>
                    <!-- END PAGE TITLE-->
                    <!-- END PAGE HEADER-->
                    <!-- BEGIN DASHBOARD STATS 1-->
                    
                    
                    @foreach($data as $dir=>$files)
                    <div class="row">
                         <?php $Categ = explode('_',$dir); $name = implode(' ',$Categ); ?>
                     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h2>  {{ucfirst($name)}} <small> ({{$files['total']}})</small></h2></div>
                     
                     @foreach($files['data'] as $fname=> $file)
                     
                     <?php $a=array("blue","red","green","yellow","brown");
                     $random_keys = array_rand($a,2); ?>
                     <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                            <a class="dashboard-stat dashboard-stat-v2 <?php echo $a[$random_keys[0]];?>" href="{{url('categories/'.$dir.'/'.$fname)}}">
                                <div class="visual">
                                    <i class="fa fa-comments"></i>
                                </div>
                                <div class="details">
                                    <div class="number">
                                        <span data-counter="counterup" data-value="1349">{{$file[$fname]}}</span>
                                    </div>
                                    <div class="desc">
                                        <?php $Categ = explode('_',$fname); $name = implode(' ',$Categ); ?>
                                         {{ucfirst($name)}}
                                   </div>
                                </div>
                            </a>
                        </div>
                        @endforeach
                    </div>
                    <div style="clear:both;display:block"></div>
                    @endforeach
                    
                    
                    
                    
                    
                    
                    
                    <div class="clearfix"></div>
                     
                 
                </div>
                <!-- END CONTENT BODY -->
            </div>
@endsection
