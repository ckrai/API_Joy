<!DOCTYPE html>
 
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
        <title>Rendezvous | Dashboard</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="{{url('public')}}/assets/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="{{url('public')}}/assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="{{url('public')}}/assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="{{url('public')}}/assets/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="{{url('public')}}/assets/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="{{url('public')}}/assets/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
                  <link href="{{url('public')}}/assets/jquery.datetimepicker.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css" integrity="sha256-Z8TW+REiUm9zSQMGZH4bfZi52VJgMqETCbPFlGRB1P8=" crossorigin="anonymous" />
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
        <!-- BEGIN HEADER -->
        <div class="page-header navbar navbar-fixed-top">
            <!-- BEGIN HEADER INNER -->
            <div class="page-header-inner ">
                <!-- BEGIN LOGO -->
                <div class="page-logo">
                    <a href="{{url('')}}">
                        <img src="{{url('public/100.png')}}" style="width: 46px;margin-top: 0px;"  alt="logo" class="logo-default" /> </a>
                    <div class="menu-toggler sidebar-toggler"> </div>
                </div>
                <!-- END LOGO -->
                <!-- BEGIN RESPONSIVE MENU TOGGLER -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
                <!-- END RESPONSIVE MENU TOGGLER -->
                <!-- BEGIN TOP NAVIGATION MENU -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                       <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                        <li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="{{url('logout')}}" class="dropdown-toggle">
                                <i class="icon-logout"></i><span style="color: white; font-size: 18px;"> Logout </span>
                            </a>
                        </li>
                        <!-- END QUICK SIDEBAR TOGGLER -->
                    </ul>
                </div>
                <!-- END TOP NAVIGATION MENU -->
            </div>
            <!-- END HEADER INNER -->
        </div>
        <!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
        <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
            <!-- BEGIN SIDEBAR -->
            <div class="page-sidebar-wrapper">
                <!-- BEGIN SIDEBAR -->
                <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
                <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
                <div class="page-sidebar navbar-collapse collapse">
                    <!-- BEGIN SIDEBAR MENU -->
                    <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
                    <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
                    <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
                    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
                    <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
                    <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
                    <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                        <!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
                        <li class="sidebar-toggler-wrapper hide">
                            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
                            <div class="sidebar-toggler"> </div>
                            <!-- END SIDEBAR TOGGLER BUTTON -->
                        </li>
                        
                        <!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
                     
                     @if(Auth::user()->role=='1')
                      <li class="nav-item <? if($pagename == 'timeline'){ echo 'active';} ?>">
                            <a href="{{url('timeline')}}" class="nav-link nav-toggle">
                                <i class="fa fa-clock-o"></i>
                                <span class="title">Timeline</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                          <li class="nav-item <? if($pagename == 'events'){ echo 'active';} ?>">
                            <a href="{{url('events')}}" class="nav-link nav-toggle">
                                <i class="icon-map"></i>
                                <span class="title">Events</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                        @endif
                        
                        
                     
                     
                     @if(Auth::user()->role=='0')
                     
                      <li class="nav-item <? if($pagename == 'home'){ echo 'active';} ?>">
                            <a href="{{url('home')}}" class="nav-link nav-toggle ">
                                <i class="icon-home"></i>
                                <span class="title">Dashboard  <?php //echo $pagename; ?></span>
                                <span class="selected"></span>
                             </a>
                        </li>
                        
                        
                        
                        
                        
                       <li class="nav-item <? if($pagename == 'sub_admin'){ echo 'active';} ?>">
                            <a href="{{url('sub-admin')}}" class="nav-link nav-toggle">
                                <i class="icon-users"></i>
                                <span class="title">Sub Admin</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                        
                     <li class="nav-item <? if($pagename == 'timeline'){ echo 'active';} ?>">
                            <a href="{{url('timeline')}}" class="nav-link nav-toggle">
                                <i class="fa fa-clock-o"></i>
                                <span class="title">Timeline</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                                
                        
                        
                        
                        <li class="nav-item <? if($pagename == 'users'){ echo 'active';} ?>">
                            <a href="{{url('users')}}" class="nav-link nav-toggle">
                                <i class="icon-users"></i>
                                <span class="title">Users</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                        
                        <li class="nav-item <? if($pagename == 'events'){ echo 'active';} ?>">
                            <a href="{{url('events')}}" class="nav-link nav-toggle">
                                <i class="icon-map"></i>
                                <span class="title">Events</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                        
                       <li class="nav-item <? if($pagename == 'customtagsmanagement'){ echo 'active';} ?>">
                            <a href="{{url('custom-tags-management')}}" class="nav-link nav-toggle">
                                <i class="icon-hourglass"></i>
                                <span class="title">Tag Management</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                        <?php $cattt = explode('/',$pagename);
                        if(isset($cattt[0]) && isset($cattt[1])){
                            $cat0 = $cattt[0];
                            $cat1 = $cattt[1];
                        }else{
                           $cat0 = '';
                            $cat1 = '';
                        }
                        ?>
                        <li class="nav-item  <? if('categories' == $cat0){ echo 'active';} ?>">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-briefcase"></i>
                                <span class="title">Categories</span>
                                <span class="selected"></span>
                                <span class="arrow open"></span>
                            </a>
                            
                            <ul class="sub-menu">
                                       @foreach($folders as $cat=>$subCategories)
                                          
                                        <li class="nav-item <? if($cat ==$cat1){ echo 'active';} ?>">
                                            <a href="javascript:;" class="nav-link nav-toggle">
                                                <? $Categ = explode('_',$cat); $categry = implode(' ',$Categ); ?>
                                                <span class="title">{{ucwords($categry)}}</span>
                                                <span class="arrow"></span>
                                            </a>
                                            @if(isset($subCategories) && is_array($subCategories))
                                           
                                            <ul class="sub-menu">
                                                 @foreach($subCategories as $subCategory)
                                                    <?  $urlact = 'categories/'.$cat.'/'.$subCategory;?>
                                                    <li class="nav-item  <? if($pagename == $urlact){ echo 'active';} ?>">
                                                          <? $SbCateg = explode('_',$subCategory); $scategry = implode(' ',$SbCateg); ?>
                                                        <a href="{{url('categories/'.$cat.'/'.$subCategory)}}" class="nav-link "> {{ucwords($scategry)}} </a>
                                                    </li>
                                                 @endforeach
                                            </ul>
                                             @endif
                                        </li>
                                       @endforeach
                            </ul>
                            
                        </li>
                        <li class="nav-item <? if($pagename == 'feedbacks'){ echo 'active';} ?>">
                            <a href="{{url('feedbacks')}}" class="nav-link nav-toggle">
                                <i class="icon-question"></i>
                                <span class="title">Feedbacks</span>
                                <span class="selected"></span>
                             </a>
                        </li>
                     @endif
                    </ul>
                    <!-- END SIDEBAR MENU -->
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
            </div>
            <!-- END SIDEBAR -->
            <!-- BEGIN CONTENT -->
            
            @yield('content')
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->
           
            <!-- END QUICK SIDEBAR -->
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        <div class="page-footer">
            <div class="page-footer-inner"> {{date('Y')}} &copy; Rendezvous.
                <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" title="Purchase Metronic just for 27$ and get lifetime updates for free" target="_blank">Purchase Metronic!</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->
        <!--[if lt IE 9]>
<script src="{{url('public')}}/assets/global/plugins/respond.min.js"></script>
<script src="{{url('public')}}/assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="{{url('public')}}/assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="{{url('public')}}/assets/global/scripts/datatable.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="{{url('public')}}/assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->

        <script src="{{url('public')}}/assets/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="{{url('public')}}/assets/layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
   
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha256-JirYRqbf+qzfqVtEE4GETyHlAbiCpC005yBTa4rj6xg=" crossorigin="anonymous"></script>
        
         <script>
            $(document).on("click", ".tagclass", function () {
               
                 var mytag = $(this).data('tag'); 
                 var mytagindex = $(this).data('tagindex');
                  //console.log(mytag +' ');
                  //console.log(mytagindex);
                 $(".modal-body #tagId").val( mytag );
                 $(".modal-body #tagindexid").val( mytagindex );
                 $(".modal-body #updatetagname").val( mytag );
                 
              
            });
            /*
            $("#updatetagform").submit(function(e) {
                e.preventDefault(); 
                //alert('hello');
                var mtagname = $('#updatetagname').val();
                var res = mtagname.charAt(0)
                if(res == '#'){
                    var form = $(this);
                    var url = form.attr('action');
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(), // serializes the form's elements.
                           success: function(data){
                              console.log(data);
                              if(data == 'yes'){
                                       alert('Approved Successfully'); 
                                     
                                    //  $(".successresponce").css({ "color": "#fff", "padding": "7px","background": "green" });
                                     // $('.modal').modal('hide');
                                      window.location.reload();
                                     // setTimeout(function(){ $('.successresponce').css({ "display": "none" });}, 3000);
                                   }
                           }
                    });
                }else{
                     alert('Please add # before tag');
                   
                }
             
                   
             });
             */
        </script>
        <script>
            $(document).on("click", ".tagclass", function () {
               
                 var mytag = $(this).data('tag'); 
                 var mytagindex = $(this).data('tagindex');
                  //console.log(mytag +' ');
                  //console.log(mytagindex);
                 $(".modal-body #tagId").val( mytag );
                 $(".modal-body #tagindexid").val( mytagindex );
              
            });
            $("#updatetagform").submit(function(e) {
                e.preventDefault(); 
                //alert('hello');
                var mtagname = $('#updatetagname').val();
                var res = mtagname.charAt(0)
                if(res == '#'){
                    var form = $(this);
                    var url = form.attr('action');
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(), // serializes the form's elements.
                           success: function(data){
                              console.log(data);
                              if(data == 'yes'){
                                       alert('Updated Successfully'); 
                                     
                                    //  $(".successresponce").css({ "color": "#fff", "padding": "7px","background": "green" });
                                     // $('.modal').modal('hide');
                                      window.location.reload();
                                     // setTimeout(function(){ $('.successresponce').css({ "display": "none" });}, 3000);
                                   }
                           }
                    });
                }else{
                     alert('Please add # before tag');
                }
             
                   
             });
        </script>
            
    
    <script>
        $("#add_custom_tag_form").submit(function(e) {
                    e.preventDefault(); // avoid to execute the actual submit of the form.
                var mtagname = $('#tagnamecu').val();
                var res = mtagname.charAt(0)
                if(res == '#'){
                   // alert('ajax');
                     var form = $(this);
                    var url = form.attr('action');
                
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(), // serializes the form's elements.
                           success: function(data)
                           {
                              
                               
                               alert(data.error_message); // show response from the php script.
                               if(data.error_code=='200'){ window.location.reload();}
                           }
                         }); 
                }else{
                    alert('Please add # before tag');
                }
                  
                });
                 $(".add_selected_tag_injson").submit(function(e) {
                    e.preventDefault(); 
                 // alert('hello');
                    var checkval =  'checkfun';
                    var form = $(this);
                    var url = form.attr('action');
             
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(),
                           success: function(data)
                           {
                              console.log(data);
                              
                                  $('.successresponce').text('Tag Added Successfully');
                                  $(".successresponce").css({ "color": "#fff", "padding": "7px","background": "green" });
                                  $('.modal').modal('hide');
                                 
                                  setTimeout(function(){ $('.successresponce').css({ "display": "none" }); 
                                  window.location.reload();
                                    }, 3000);
                           
                              
                           }
                         });
                        
                    
                        
                });
                 
               
               
    </script>
    
         
        @yield('script')
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html>