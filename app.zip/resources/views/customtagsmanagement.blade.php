@extends('layouts.map-layout')
@section('content')
<?php
//echo 'hello'; exit;?>

   <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                  
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
     
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                  
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i> 
                                        <? $Categ = explode('_',$category); $categry = implode(' ',$Categ); ?>
                                        <? $SbCateg = explode('_',$subcategory); $sbcategry = implode(' ',$SbCateg); ?>
                                        <span class="caption-subject bold uppercase">Custom Tag Management </span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <!--div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                      <button type="button" class="btn sbold green" data-toggle="modal" data-target="#myModal"  > <i class="fa fa-plus"></i>Add new</button>
                                                    
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="col-md-6"></div>
                                        </div>
                                    </div-->
                                    
                                    
                                    
                                      <p class="successresponce"></p>
                                      <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th> S No. </th>
                                                <th> Custom Tag </th>
                                                <th> Category</th>
                                                <th> User </th>
                                                <th> Date </th>
                                                <th> Actions </th>
                                                
                                               
                                            </tr>
                                        </thead>
                                         <tbody>
                                                <?php $i=0; $j=1;?> 
                                                @foreach($custom as $customtag)
                                                 <tr>
                                                    <td>{{$j}}</td><? //{{$customtag->id}} ?>
                                                    <td><a href="#">{{$customtag->custom_tag}}</a></td>
                                                    <td><?php $column= (explode("_",$customtag->column)); 
                                                   // print_r($column);
                                                     // echo $customtag->column;
                                                   $catname =  implode(' ',$column);
                                                    if($customtag->column == 'job_title' || $customtag->column == 'company'  || $customtag->column == 'work_extra_skills' || $customtag->column == 'colleges'  || $customtag->column == 'major' || $customtag->column == 'education_extra_skill'){
                                                       
                                                        $custcatname = 'professional';
                                                    }else{
                                                          
                                                          $custcatname = $catname;
                                                    }
                                                        echo ucwords($custcatname);
                                                   // echo ucfirst(isset($column[0])?$column[0]:''); 
                                                    //echo ' '. ucfirst(isset($column[1])?$column[1]:''); 
                                                    //echo ' '. ucfirst(isset($column[2])?$column[2]:''); ?>    
                                                    </td>                        
                                                    <td> {{$customtag->username}}</td>
                                                    <td> {{$customtag->created_at}}</td>
                            				    	<td>
                             						<?php 
                             						$str = $customtag->custom_tag;
                             					    $tag = ltrim($str, '#'); 
                             						//$tagname =  base64_decode($customtag->custom_tag); ?>
                             							<!--a href="{{url('approve-custom-tag/'. $tag.'/'.$customtag->column)}}" onclick="return confirm('Are you sure you want to approve ?' )" class="btn btn-xs btn-success" title="Activate" data-toggle="tooltip">Approve</a-->
                            						    <a type="button"  class="btn btn-xs btn-success currentclas"  data-toggle="modal"  data-target="#approvemodal_<?php echo $i;//echo $customtag->column; ?>" title="Activate" data-toggle="tooltip">Approve</a>
                            						    <!--a data-target="#myModal" href="{{url('approve-custom-tag/'. $tag.'/'.$customtag->column)}}"  class="btn btn-xs btn-success" title="Activate" data-toggle="tooltip">Approve</a-->
                            						    @if(!$customtag->declined)
                            						    <a href="{{url('adecline-custom-tag/'.$customtag->id)}}" onclick="return confirm('Are you sure you want to decline ?' )" class="btn btn-xs btn-danger" title="Decline" data-toggle="tooltip">Decline</a>
                                                        @endif
                            						
                            						</td>
                                                </tr>
                                                      <!-- Modal -->
                                                  <div class="modal fade" id="approvemodal_<?php echo $i;//$customtag->column;?>" role="dialog">
                                                       
                                                    <div class="modal-dialog">
                                                    
                                                      <div class="modal-content">
                                                          <form class="add_selected_tag_injson"  action="{{url('api/new-add-custom-tag')}}">
                                                              {{ csrf_field() }}
                                                        <div class="modal-header">
                                                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                          <h4 class="modal-title">Approve Tag</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                          
                                                               <input type="hidden" value="<?php //echo $tagvalue = $customtag->custom_tag;?>{{$customtag->custom_tag}}" name="custagvalue">
                                                               <input type="hidden" value="<?php //echo $tagvalue = $customtag->custom_tag;?>{{$customtag->id}}" name="custagid">
                                                          <p><?php if( $customtag->column == 'about_me'){ 
                                                              ?>
                                                                 <label> Select Sub Category : </label>
                                                              <select name="about_me">
                                                                  <option value="character_traits" >Character Traits</option>
                                                                  <option value="disabilities" >Disabilities</option>
                                                                  <option value="nationality" >Nationality</option>
                                                                  <option value="personality_types" >Personality Types</option>
                                                                  <option value="philosophy" >Philosophy</option>
                                                                  <option value="politics" >Politics</option>
                                                                  <option value="relationships" >Relationships</option>
                                                                  <option value="religion" >Religion</option>
                                                              </select>
                                                         
                                                              <?
                                                          }elseif($customtag->column == 'food_drink'){
                                                            ?>
                                                               <label> Select Sub Category : </label>
                                                             <select name="food_drink">
                                                                  <option value="brands" >Brands</option>
                                                                  <option value="drinks" >Drinks</option>
                                                                  <option value="etc" >Etc</option>
                                                                  <option value="food" >Food</option>
                                                                  <option value="influencer" >Influencer</option>
                                                                  <option value="lifestyle" >Lifestyle</option>
                                                                  <option value="places" >Places</option>
                                                                  <option value="regional" >Regional</option>
                                                              </select>
                                                           
                                                            <?
                                                          }elseif($customtag->column == 'entertainment'){
                                                               ?>
                                                                  <label> Select Sub Category : </label>
                                                                <select name="entertainment">
                                                                  <option value="authors" >Authors</option>
                                                                  <option value="book_genre" >Book Genre</option>
                                                                  <option value="books" >Books</option>
                                                                  <option value="genre" >Genre</option>
                                                                  <option value="misc" >Misc</option>
                                                                  <option value="movies" >Movies</option>
                                                                  <option value="music_act" >Music Act</option>
                                                                  <option value="music_genre" >Music Genre</option>
                                                                  <option value="podcast_creator" >Podcast Creator</option>
                                                                  <option value="podcast_genres" >Podcast Genres</option>
                                                                  <option value="podcast" >Podcast</option>
                                                                  <option value="standup_comedians" >Standup Comedians</option>
                                                                  <option value="streaming_service_original_content" >Streaming Service Original Content</option>
                                                                  <option value="tv_shows" >TV Shows</option>
                                                                </select>
                                                           
                                                            <?
                                                              
                                                          }elseif($customtag->column == 'fitness_and_hobbies'){
                                                              ?>
                                                                 <label> Select Sub Category : </label>
                                                              <select name="fitness_and_hobbies">
                                                                  <option value="console_games" >Console Games</option>
                                                                  <option value="hobbies" >Hobbies</option>
                                                                  <option value="phone_games" >Phone Games</option>
                                                                  <option value="sports" >Sports</option>
                                                              </select>
                                                             
                                                              <?
                                                              
                                                          }elseif($customtag->column == 'travel_and_places'){
                                                               ?>
                                                                  <label> Select Sub Category : </label>
                                                                <select name="travel_and_places">
                                                                  <option value="cities" >Cities</option>
                                                                  <option value="countries" >Countries</option>
                                                                  <option value="environments" >Environments</option>
                                                                  <option value="general_places" >General Places</option>
                                                                  <option value="parks_beaches" >Parks Beaches</option>
                                                                  <option value="specific_places_brands" >Specific Places Brands</option>
                                                                </select>
                                                             
                                                              <?
                                                          }elseif($customtag->column == 'animal_lover'){
                                                              ?>
                                                                 <label> Select Sub Category : </label>
                                                               <select name="animal_lover">
                                                                  <option value="celebrity_pets" >Celebrity Pets</option>
                                                                  <option value="pets" >Pets</option>
                                                                  <option value="wild_animals" >Wild Animals</option>
                                                                  <option value="imaginary_animals" >Imaginary Animals </option>
                                                                </select>
                                                             
                                                              <?
                                                          }elseif($customtag->column == 'job_title' || $customtag->column == 'company'  || $customtag->column == 'work_extra_skills' || $customtag->column == 'colleges'  || $customtag->column == 'major' || $customtag->column == 'education_extra_skill'){
                                                              ?>
                                                              <label> Select Sub Category : </label>
                                                               <select name="{{$customtag->column}}">
                                                                   <? $procat = explode('_',$customtag->column); $Pcategry = implode(' ',$procat); ?>
                                                                  <option value="{{$customtag->column}}" >{{ucwords($Pcategry)}}</option>
                                                                </select>
                                                             
                                                              <?
                                                          }  ?></p>
                                                          
                                                        
                                                        </div>
                                                        <div class="modal-footer">
                                                             <button type="submit" class="btn btn-primary">Submit</button>
                                                          <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
                                                        </div>
                                                          </form>
                                                      </div>
                                                      
                                                    </div>
                                                  </div><?php $i++; $j++;?>
                            				 @endforeach
                                            </tbody>
                                    </table>
                              
                            
                                
                              
                            
                              <!-- Modal -->
                              <div class="modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">
                                
                                  <!-- Modal content-->
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      <h4 class="modal-title">New Custom Tags</h4>
                                    </div>
                                    <div class="modal-body">
                                      <form id="add_custom_tag_form" action="{{url('api/add-custom-tag')}}">
                                              <div class="form-group">
                                                <label for="exampleInputEmail1">Custom Tag</label>
                                                <input type="text" required class="form-control" id="tagnamecu" name="custom_tag" placeholder="#tag"   >
                                               </div>
                                              <div class="form-group">
                                                <label for="exampleInputPassword1">Category</label>
                                                <select name="column"  required class="form-control">
                                                                <option value="">Select a Category</option>
                                                                <option value="about_me">About Me</option>
                                                                <option value="animal_lover">Animal Lover</option>
                                                                <option value="company">Company</option>
                                                                <option value="colleges">Colleges</option>
                                                                
                                                                 <option value="entertainment">Entertainment</option>
                                                                 <option value="education_extra_skill">Education Extra Skill</option>
                                                                 
                                                                 <option value="fitness_and_hobbies">Fitness And Hobbies</option>
                                                                <option value="food_drink">Food Drink</option>
                                                                <option value="general">General</option>
                                                                
                                                                
                                                                 <option value="job_title">Job Title</option>
                                                                <option value="major">Major</option>
                                                                 <option value="travel_and_places">Travel & Places</option>
                                                                <option value="work_extra_skills">Work Extra Skills</option>
                                                    </select>
                                                    
                                              </div>
                                             
                                              <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                    </div>
                                    
                                  </div>
                                  
                                </div>
                              </div>
                              
                             </div>
                            </div>
                           
                        </div>
                    </div>
                 </div>
                <!-- END CONTENT BODY -->
            </div> 
    
                           		                              		                            
@endsection