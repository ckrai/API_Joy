@extends('layouts.map-layout')
@section('content')
   <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                  
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
     
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                  
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                   <div class="col-md-6">  
                                        <div class="caption font-dark">
                                            <i class="icon-settings font-dark"></i> 
                                            <span class="caption-subject bold uppercase">Events</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                         <a type="button" class="btn sbold green pull-right" href="{{url('new-event')}}"  > <i class="fa fa-plus"></i>Add New</a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                  
                                     <p class="successresponce"></p>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Title</th>						
                        						<th>Location</th>
                        						<th>Time</th>
                        						
                        						
                        						
                                             </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; ?> 
                                            @foreach($events as $event)
                                             <tr>
                                                <td>{{++$i}}</td>
                                                <td><a href="#">{{$event->title}}</a></td>
                                                <td>{{$event->location}}</td>                        
                                               <td>{{$event->time}}</td> 
                        					 
                                            </tr>
                        				 @endforeach
                                        </tbody>
                                    </table>
                                    
                                 
                                </div>
                            </div>
                           
                        </div>
                    </div>
                 </div>
                <!-- END CONTENT BODY -->
            </div>
           
  @endsection
  
