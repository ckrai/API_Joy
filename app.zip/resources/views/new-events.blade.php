@extends('layouts.map-layout')
@section('content')

 
   <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                  
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
     
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                       <div class="pac-card" id="pac-card">
      <div>
        <div id="title">
          Autocomplete search
        </div>
        <div id="type-selector" class="pac-controls">
          <input type="radio" name="type" id="changetype-all" checked="checked">
          <label for="changetype-all">All</label>

          <input type="radio" name="type" id="changetype-establishment">
          <label for="changetype-establishment">Establishments</label>

          <input type="radio" name="type" id="changetype-address">
          <label for="changetype-address">Addresses</label>

          <input type="radio" name="type" id="changetype-geocode">
          <label for="changetype-geocode">Geocodes</label>
        </div>
        <div id="strict-bounds-selector" class="pac-controls">
          <input type="checkbox" id="use-strict-bounds" value="">
          <label for="use-strict-bounds">Strict Bounds</label>
        </div>
      </div>
      <div id="pac-container">
        <input id="pac-input" type="text"
            placeholder="Enter a location">
      </div>
    </div>
    <div id="map"></div>
    <div id="infowindow-content">
      <img src="" width="16" height="16" id="place-icon">
      <span id="place-name"  class="title"></span><br>
      <span id="place-address"></span>
    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                   <div class="col-md-6">  
                                        <div class="caption font-dark">
                                            <i class="icon-settings font-dark"></i> 
                                            <span class="caption-subject bold uppercase">New Event</span>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="portlet-body"> 
                                 <form action="{{url('api/new-add-event-data')}}" id="form_sample_1" class="form-horizontal" method="post">
                                        <div class="form-body">
                                            <div class="alert alert-danger display-hide">
                                                <button class="close" data-close="alert"></button> You have some form errors. Please check below. </div>
                                            <!--div class="alert alert-success display-hide">
                                                <button class="close" data-close="alert"></button> Your form validation is successful! </div-->
                                            <div class="alert alert-success display-hide successresponce"></div>    
                                            <div class="form-group">
                                                <label class="control-label col-md-3">Title
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <input type="text" name="name" data-required="1" class="form-control" id="title" /> </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-md-3">Description
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <textarea  name="description" required   class="form-control" id="desc" ></textarea> </div>
                                            </div>
                                           
                                            <div class="form-group">
                                                <label class="control-label col-md-3">Date & Time 
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <input name="filter-date" id="filter-date" required /> </div>
                                            </div>
                                            
                                             <div class="form-group">
                                                <label class="control-label col-md-3">Address 
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <input name="address" id="address" required /> </div>
                                            </div>
                                              <div class="form-group">
                                                <label class="control-label col-md-3">Address 2 
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <input id="searchTextField" type="text" size="50" placeholder="Enter a location" autocomplete="on"></div>
                                            </div>
                                            
                                             <div class="form-group">
                                                <label class="control-label col-md-3">Latitude 
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <input name="latitude" id="latitude" required /> </div>
                                            </div>
                                            
                                             <div class="form-group">
                                                <label class="control-label col-md-3">Longitude
                                                    <span class="required"> * </span>
                                                </label>
                                                <div class="col-md-4">
                                                    <input name="longitude" id="longitude" required /> </div>
                                            </div>
                                           <input type="hidden" value="{{Auth::user()->id}}" name="user_id" >
                                          
                                       
                                          
                                        </div>
                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="submit" class="btn green">Submit</button>
                                                    <button type="button" class="btn grey-salsa btn-outline">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                
                                
                                </div>
                            </div>
                           
                        </div>
                    </div>
                 </div>
                <!-- END CONTENT BODY -->
            </div>
           
 
 


 
           
  @endsection
  @section('script')
  
      <script>
      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -33.8688, lng: 151.2195},
          zoom: 13
        });
        var card = document.getElementById('pac-card');
        var input = document.getElementById('pac-input');
        var types = document.getElementById('type-selector');
        var strictBounds = document.getElementById('strict-bounds-selector');

        map.controls[google.maps.ControlPosition.TOP_RIGHT].push(card);

        var autocomplete = new google.maps.places.Autocomplete(input);

        // Bind the map's bounds (viewport) property to the autocomplete object,
        // so that the autocomplete requests use the current map bounds for the
        // bounds option in the request.
        autocomplete.bindTo('bounds', map);

        // Set the data fields to return when the user selects a place.
        autocomplete.setFields(
            ['address_components', 'geometry', 'icon', 'name']);

        var infowindow = new google.maps.InfoWindow();
        var infowindowContent = document.getElementById('infowindow-content');
        infowindow.setContent(infowindowContent);
        var marker = new google.maps.Marker({
          map: map,
          anchorPoint: new google.maps.Point(0, -29)
        });

        autocomplete.addListener('place_changed', function() {
          infowindow.close();
          marker.setVisible(false);
          var place = autocomplete.getPlace();
          if (!place.geometry) {
            // User entered the name of a Place that was not suggested and
            // pressed the Enter key, or the Place Details request failed.
            window.alert("No details available for input: '" + place.name + "'");
            return;
          }

          // If the place has a geometry, then present it on a map.
          if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
          } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);  // Why 17? Because it looks good.
          }
          marker.setPosition(place.geometry.location);
          marker.setVisible(true);

          var address = '';
          if (place.address_components) {
            address = [
              (place.address_components[0] && place.address_components[0].short_name || ''),
              (place.address_components[1] && place.address_components[1].short_name || ''),
              (place.address_components[2] && place.address_components[2].short_name || '')
            ].join(' ');
          }

          infowindowContent.children['place-icon'].src = place.icon;
          infowindowContent.children['place-name'].textContent = place.name;
          infowindowContent.children['place-address'].textContent = address;
          infowindow.open(map, marker);
        });

        // Sets a listener on a radio button to change the filter type on Places
        // Autocomplete.
        function setupClickListener(id, types) {
          var radioButton = document.getElementById(id);
          radioButton.addEventListener('click', function() {
            autocomplete.setTypes(types);
          });
        }

        setupClickListener('changetype-all', []);
        setupClickListener('changetype-address', ['address']);
        setupClickListener('changetype-establishment', ['establishment']);
        setupClickListener('changetype-geocode', ['geocode']);

        document.getElementById('use-strict-bounds')
            .addEventListener('click', function() {
              console.log('Checkbox clicked! New state=' + this.checked);
              autocomplete.setOptions({strictBounds: this.checked});
            });
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCXqXFbbi76VpnEX3lHNsrjKRGhPdFIHNg&libraries=places&callback=initMap"
        async defer></script>
        
 
         <script src="{{url('public')}}/assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
         <script src="{{url('public')}}/assets/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/bootstrap-markdown/lib/markdown.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
                  <script src="{{url('public')}}/assets/pages/scripts/form-validation.min.js" type="text/javascript"></script>
         <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
  
        
        <script src="{{url('public')}}/assets/jquery.datetimepicker.js" type="text/javascript"></script>
        <script src="{{url('public')}}/assets/jquery.datetimepicker.full.js" type="text/javascript"></script>
       
        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';
                
                jQuery('#filter-date').datetimepicker();
            });
             $("#form_sample_1").submit(function(e) {
                    e.preventDefault();
                   var title = $('#title').val();
                   var desc = $('#desc').val();
                   var datep = $('#filter-date').val();
                   var address = $('#address').val();
                   var latitude = $('#latitude').val();
                   var longitude = $('#longitude').val();
                   var user_id='{{Auth::user()->id}}';
                   
                    //alert(title);
                    var form = $(this);
                    var url = form.attr('action');
                   
                if(title != '' && desc !='' && datep !='' && address !='' && latitude !='' && longitude !='' && user_id!=''){
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(), // serializes the form's elements.
                           success: function(data)
                           {
                              if(data.error_code=='200') {
                                   swal({
                                        title: "Success!",
                                        text: 'Event Added Successfully!',
                                        type: "success"
                                        }).then(function() {
                                         window.location.reload();
                                        });
                               
                             }
                           }
                     });
                } 
                });
              
        </script>
  @endsection

 