<?php
//echo 'hello'; exit;?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> Custom Tags</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
    body {
        color: #566787;
		background: #f5f5f5;
		font-family: 'Varela Round', sans-serif;
		font-size: 13px;
	}
	.table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px 0;
		border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
	.table-title {
		padding-bottom: 15px;
		background: #299be4;
		color: #fff;
		padding: 16px 30px;
		margin: -20px -25px 10px;
		border-radius: 3px 3px 0 0;
    }
    .table-title h2 {
		margin: 5px 0 0;
		font-size: 24px;
	}
	.table-title .btn {
		color: #566787;
		float: right;
		font-size: 13px;
		background: #fff;
		border: none;
		min-width: 50px;
		border-radius: 2px;
		border: none;
		outline: none !important;
		margin-left: 10px;
	}
	.table-title .btn:hover, .table-title .btn:focus {
        color: #566787;
		background: #f2f2f2;
	}
	.table-title .btn i {
		float: left;
		font-size: 21px;
		margin-right: 5px;
	}
	.table-title .btn span {
		float: left;
		margin-top: 2px;
	}
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
		padding: 12px 15px;
		vertical-align: middle;
    }
	table.table tr th:first-child {
		width: 60px;
	}
	table.table tr th:last-child {
		width: 100px;
	}
    table.table-striped tbody tr:nth-of-type(odd) {
    	background-color: #fcfcfc;
	}
	table.table-striped.table-hover tbody tr:hover {
		background: #f5f5f5;
	}
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }	
    table.table td:last-child i {
		opacity: 0.9;
		font-size: 22px;
        margin: 0 5px;
    }
	table.table td a {
		font-weight: bold;
		color: #566787;
		display: inline-block;
		text-decoration: none;
	}
	table.table td a:hover {
		color: #2196F3;
	}
	table.table td a.settings {
        color: #2196F3;
    }
    table.table td a.delete {
        color: #F44336;
    }
    table.table td i {
        font-size: 19px;
    }
	table.table .avatar {
		border-radius: 50%;
		vertical-align: middle;
		margin-right: 10px;
	}
	.status {
		font-size: 30px;
		margin: 2px 2px 0 0;
		display: inline-block;
		vertical-align: middle;
		line-height: 10px;
	}
    .text-success {
        color: #10c469;
    }
    .text-info {
        color: #62c9e8;
    }
    .text-warning {
        color: #FFC107;
    }
    .text-danger {
        color: #ff5b5b;
    }
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }	
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {        
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
    ul.pagination {
    border: 1px solid;
    margin-bottom: 80px;
    margin-top: 40px;
}
.btn{
   color: white !important;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});
</script>
</head>
<body>
    <div class="container" style="background:white">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-5">
						<h2>Custom Tag <b>Management</b></h2>
					</div>
					<div class="col-sm-7">
						    <button type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal" style="    color: black !important;" >Add new</button>					
					</div>
                </div>
                
            </div>
            <p class="successresponce"></p>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th width="4%">#</th>
                        <th width="20%" style=" <?php if(isset($_REQUEST['order_by']) && ($_REQUEST['order_by']=='custom_tag')){ echo 'color: white;background: #299be4;';  } ?>   cursor: pointer;" onclick="window.location='<?php echo url('custom_tags?order_by=custom_tag&order=ASC'); ?>'">Custom Tag</th>						
						<th width="20%" style=" <?php if(isset($_REQUEST['order_by']) && ($_REQUEST['order_by']=='column')){ echo 'color: white;background: #299be4;';  } ?>   cursor: pointer;" onclick="window.location='<?php echo url('custom_tags?order_by=column&order=ASC'); ?>'">Category</th>
						<th width="20%" style=" <?php if(isset($_REQUEST['order_by']) && ($_REQUEST['order_by']=='username')){ echo 'color: white;background: #299be4;';  } ?>   cursor: pointer;" onclick="window.location='<?php echo url('custom_tags?order_by=username&order=ASC'); ?>'">User</th>
						<th width="18%" style=" <?php if(isset($_REQUEST['order_by']) && ($_REQUEST['order_by']=='created_at')){ echo 'color: white;background: #299be4;';  } ?>   cursor: pointer;" onclick="window.location='<?php echo url('custom_tags?order_by=created_at&order=DESC'); ?>'">Date</th>
						<th width="18%">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=0; ?> 
                    @foreach($custom as $customtag)
                     <tr>
                        <td>{{$customtag->id}}</td>
                        <td><a href="#">{{$customtag->custom_tag}}</a></td>
                        <td><?php $column= (explode("_",$customtag->column)); 
                       // print_r($column);
                         // echo $customtag->column;
                       $catname =  implode(' ',$column);
                        if($customtag->column == 'job_title' || $customtag->column == 'company'  || $customtag->column == 'work_extra_skills' || $customtag->column == 'colleges'  || $customtag->column == 'major' || $customtag->column == 'education_extra_skill'){
                           
                            $custcatname = 'professional';
                        }else{
                              
                              $custcatname = $catname;
                        }
                            echo ucwords($custcatname);
                       // echo ucfirst(isset($column[0])?$column[0]:''); 
                        //echo ' '. ucfirst(isset($column[1])?$column[1]:''); 
                        //echo ' '. ucfirst(isset($column[2])?$column[2]:''); ?>    
                        </td>                        
                        <td> {{$customtag->username}}</td>
                        <td> {{$customtag->created_at}}</td>
				    	<td>
 						<?php 
 						$str = $customtag->custom_tag;
 					    $tag = ltrim($str, '#'); 
 						//$tagname =  base64_decode($customtag->custom_tag); ?>
 							<!--a href="{{url('approve-custom-tag/'. $tag.'/'.$customtag->column)}}" onclick="return confirm('Are you sure you want to approve ?' )" class="btn btn-xs btn-success" title="Activate" data-toggle="tooltip">Approve</a-->
						    <a type="button"  class="btn btn-xs btn-success currentclas"  data-toggle="modal"  data-target="#approvemodal_<?php echo $i; ?>" title="Activate" data-toggle="tooltip">Approve</a>
						    <!--a data-target="#myModal" href="{{url('approve-custom-tag/'. $tag.'/'.$customtag->column)}}"  class="btn btn-xs btn-success" title="Activate" data-toggle="tooltip">Approve</a-->
						    @if(!$customtag->declined)
						    <a href="{{url('decline-custom-tag/'.$customtag->id)}}" onclick="return confirm('Are you sure you want to decline ?' )" class="btn btn-xs btn-danger" title="Decline" data-toggle="tooltip">Decline</a>
                            @endif
						
						</td>
                    </tr>
                          <!-- Modal -->
  <div class="modal fade" id="approvemodal_<?php echo $i;?>" role="dialog">
       
    <div class="modal-dialog">
    
      <div class="modal-content">
          <form class="add_selected_tag_injson"  action="{{url('api/new-add-custom-tag')}}">
              {{ csrf_field() }}
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Approve Tag</h4>
        </div>
        <div class="modal-body">
          
               <input type="hidden" value="<?php //echo $tagvalue = $customtag->custom_tag;?>{{$customtag->custom_tag}}" name="custagvalue">
          <p><?php if( $customtag->column == 'about_me'){ 
              ?>
             <p><input type="radio" value="character_traits" name="about_me" required> Character Traits </p>
             <p> <input type="radio" value="disabilities" name="about_me"> Disabilities </p>
             <p> <input type="radio" value="nationality" name="about_me"> Nationality </p>
             <p> <input type="radio" value="personality_types" name="about_me"> Personality Types </p>
             <p> <input type="radio" value="philosophy" name="about_me"> Philosophy </p>
             <p> <input type="radio" value="politics" name="about_me"> Politics </p>
             <p> <input type="radio" value="relationships" name="about_me"> Relationships </p>
             <p> <input type="radio" value="religion" name="about_me"> Religion </p>
              <?
          }elseif($customtag->column == 'food_drink'){
            ?>
             <p> <input type="radio" value="brands" name="food_drink" required> Brands </p>
             <p> <input type="radio" value="drinks" name="food_drink"> Drinks </p>
             <p> <input type="radio" value="etc" name="food_drink"> Etc </p>
             <p> <input type="radio" value="food" name="food_drink"> Food </p>
             <p> <input type="radio" value="influencer" name="food_drink"> Influencer </p>
             <p> <input type="radio" value="lifestyle" name="food_drink"> Lifestyle </p>
             <p> <input type="radio" value="places" name="food_drink"> Places </p>
             <p> <input type="radio" value="regional" name="food_drink"> Regional </p>
            <?
          }elseif($customtag->column == 'entertainment'){
               ?>
             <p> <input type="radio" value="authors" name="entertainment" required> Authors </p>
             <p> <input type="radio" value="book_genre" name="entertainment"> Book Genre </p>
             <p> <input type="radio" value="books" name="entertainment"> Books </p>
             <p> <input type="radio" value="genre" name="entertainment"> Genre </p>
             <p> <input type="radio" value="misc" name="entertainment"> Misc </p>
             <p> <input type="radio" value="movies" name="entertainment"> Movies </p>
             <p> <input type="radio" value="music_act" name="entertainment"> Music Act </p>
             <p> <input type="radio" value="music_genre" name="entertainment"> Music Genre </p>
             <p> <input type="radio" value="podcast_creator" name="entertainment"> Podcast Creator </p>
             <p> <input type="radio" value="podcast_genres" name="entertainment"> Podcast Genres </p>
             <p> <input type="radio" value="podcast" name="entertainment"> Podcast </p>
             <p> <input type="radio" value="standup_comedians" name="entertainment"> Standup Comedians </p>
             <p> <input type="radio" value="streaming_service_original_content" name="entertainment"> Streaming Service Original Content </p>
             <p> <input type="radio" value="tv_shows" name="entertainment"> TV Shows </p>
            <?
              
          }elseif($customtag->column == 'fitness_and_hobbies'){
              ?>
              <p> <input type="radio" value="console_games" name="fitness_and_hobbies" required> Console Games </p>
              <p> <input type="radio" value="hobbies" name="fitness_and_hobbies"> Hobbies </p>
              <p> <input type="radio" value="phone_games" name="fitness_and_hobbies"> Phone Games </p>
              <p> <input type="radio" value="sports" name="fitness_and_hobbies"> Sports </p>
              <?
              
          }elseif($customtag->column == 'travel_and_places'){
               ?>
              <p> <input type="radio" value="cities" name="travel_and_places"> Cities </p>
              <p> <input type="radio" value="countries" name="travel_and_places"> Countries </p>
              <p> <input type="radio" value="environments" name="travel_and_places"> Environments </p>
              <p> <input type="radio" value="general_places" name="travel_and_places"> General Places </p>
              <p> <input type="radio" value="parks_beaches" name="travel_and_places"> Parks Beaches </p>
              <p> <input type="radio" value="specific_places_brands" name="travel_and_places"> Specific Places Brands </p>
              <?
          }elseif($customtag->column == 'animal_lover'){
              ?>
              <p> <input type="radio" value="celebrity_pets" name="animal_lover" required> Celebrity_pets </p>
              <p> <input type="radio" value="pets" name="animal_lover"> Pets </p>
              <p> <input type="radio" value="wild_animals" name="animal_lover"> Wild Animals </p>
              <p> <input type="radio" value="imaginary_animals" name="animal_lover">Imaginary Animals </p>
              <?
          }elseif($customtag->column == 'job_title' || $customtag->column == 'company'  || $customtag->column == 'work_extra_skills' || $customtag->column == 'colleges'  || $customtag->column == 'major' || $customtag->column == 'education_extra_skill'){
              ?>
              <p> <input type="radio" value="{{$customtag->column}}" name="{{$customtag->column}}" required> {{ucwords($customtag->column)}} </p>
              <?
          }  ?></p>
          
        
        </div>
        <div class="modal-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
        </div>
          </form>
      </div>
      
    </div>
  </div><?php $i++;?>
				 @endforeach
                </tbody>
            </table>
			  <div style="display:block,clear:both"></div>
          {{ $custom->appends(request()->query())->links() }}
 
        </div>
    </div>  

    
  

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">New Custom Tags</h4>
        </div>
        <div class="modal-body">
          <form id="add_custom_tag_form" action="{{url('api/add-custom-tag')}}">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Custom Tag</label>
                    <input type="text" required class="form-control" id="tagnamecu" name="custom_tag" placeholder="#tag"   >
                   </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Category</label>
                    <select name="column"  required class="form-control">
                                    <option value="">Select a Category</option>
                                    <option value="about_me">About Me</option>
                                    <option value="animal_lover">Animal Lover</option>
                                    <option value="company">Company</option>
                                    <option value="colleges">Colleges</option>
                                    
                                     <option value="entertainment">Entertainment</option>
                                     <option value="education_extra_skill">Education Extra Skill</option>
                                     
                                     <option value="fitness_and_hobbies">Fitness And Hobbies</option>
                                    <option value="food_drink">Food Drink</option>
                                    <option value="general">General</option>
                                    
                                    
                                     <option value="job_title">Job Title</option>
                                    <option value="major">Major</option>
                                     <option value="travel_and_places">Travel & Places</option>
                                    <option value="work_extra_skills">Work Extra Skills</option>
                        </select>
                        
                  </div>
                 
                  <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
        
      </div>
      
    </div>
  </div>
  
     
    
    <script>
        $("#add_custom_tag_form").submit(function(e) {
                    e.preventDefault(); // avoid to execute the actual submit of the form.
                var mtagname = $('#tagnamecu').val();
                var res = mtagname.charAt(0)
                if(res == '#'){
                   // alert('ajax');
                     var form = $(this);
                    var url = form.attr('action');
                
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(), // serializes the form's elements.
                           success: function(data)
                           {
                              
                               
                               alert(data.error_message); // show response from the php script.
                               if(data.error_code=='200'){ window.location.reload();}
                           }
                         }); 
                }else{
                    alert('Please add # before tag');
                }
                  
                });
                 $(".add_selected_tag_injson").submit(function(e) {
                    e.preventDefault(); // avoid to execute the actual submit of the form.
                   // var idname = $('.add_selected_tag_injson').parent().parent().parent().attr('id');
                   // console.log(idname);
                   
                    var checkval =  'checkfun';
                    var form = $(this);
                    var url = form.attr('action');
               
                    $.ajax({
                           type: "POST",
                           url: url,
                           data: form.serialize(), // serializes the form's elements.
                           success: function(data)
                           {
                              console.log(data);
                               if(data == 'yes'){
                                  // alert('Approved Successfully'); 
                                  $('.successresponce').text('Tag Approved Successfully');
                                  $(".successresponce").css({ "color": "#fff", "padding": "7px","background": "green" });
                                  $('.modal').modal('hide');
                                 // window.location.reload();
                                  setTimeout(function(){ $('.successresponce').css({ "display": "none" });
                                    }, 3000);
                               }
                              
                           }
                         });
                        
                        
                        
                });
               
               
    </script>
    
    
    
    
    
    
    
    
    
    
    
</body>
</html>                                		                            