@extends('layouts.map-layout')
@section('content')
   <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                  
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
     
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                  
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="col-md-6">
                                        <div class="caption font-dark">
                                            <i class="icon-settings font-dark"></i> 
                                            <? $Categ = explode('_',$category); $categry = implode(' ',$Categ); ?>
                                            <? $SbCateg = explode('_',$subcategory); $sbcategry = implode(' ',$SbCateg); ?>
                                            <span class="caption-subject bold uppercase">{{ucwords($categry)}} > {{ucwords($sbcategry)}}</span>
                                        </div>
                                   </div>
                                   <div class="col-md-6">
                                    <button type="button" class="btn sbold green pull-right" data-toggle="modal" data-target="#myModal"  > <i class="fa fa-plus"></i>Add New</button>

                                  </div>
                                   
                                   
                                </div>
                                <div class="portlet-body">
                                  
                                     <p class="successresponce"></p>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                 <th> S No. </th>
                                                <th> Tag Name </th>
                                                <th> Actions </th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                                <?php 
                                                 if($category == 'professional'){
                                                    $data =  json_decode(file_get_contents(public_path('json-data/'.$subcategory.'/'.$subcategory.'.json'))); 
                                                 }else{
                                                     $data =  json_decode(file_get_contents(public_path('json-data/'.$category.'/'.$subcategory.'.json'))); 
                                                 }
                                                 $datak = (array)( $data );
                                                 $data = array_unique($datak);
                                               // echo '<pre>'; print_r($data);echo '</pre>';
                                                 
                                                 ?>
                                                 @if(!empty($data))
                                                  <?php $p=1; ?>
                                                    @foreach($data as $tagkey => $tagvalue)
                                                  
                                                        <tr class="odd gradeX">
                                                            <td> {{$p}}</td>
                                                             <td>  <?  $tag = ltrim($tagvalue, '#');  ?> {{$tagvalue}}</td>
                                                            <td>
                                                                <div class="btn-group">
                                                                    <button class="btn btn-xs green tagclass dropdown-toggle" type="button" data-tagindex ="{{$tagkey}}" data-tag ="{{$tagvalue}}" data-toggle="modal" data-target="#updateModal"> Edit
                                                                        
                                                                    </button>
                                                                    <!--button class="btn btn-xs red tagclass dropdown-toggle deletetagfun" type="button" data-tagcat ="{{$category}}"  data-tagsubcat ="{{$subcategory}}" data-tag ="{{$tagvalue}}" onclick="return confirm('Are you sure you want to decline ?' )" > Delete
                                                                    </button-->
                                                                    <?php 
                                                                    //echo $category;
                                                                    if($category == 'professional'){
                                                                    ?>
                                                                     <a href="javascript::void(0)" onclick="if(confirm('Are you sure?')){ window.location='{{url('delete-tag/'.$subcategory.'/'.$subcategory.'/'. $tag)}}' } "        class="btn btn-xs btn-danger" title="Delete" data-toggle="tooltip">Delete</a>
                                                                     <?php }else{ ?>
                                                                     <a href="javascript::void(0)" onclick="if(confirm('Are you sure?')){ window.location='{{url('delete-tag/'.$category.'/'.$subcategory.'/'. $tag)}}' } "        class="btn btn-xs btn-danger" title="Delete" data-toggle="tooltip">Delete</a>
                                                                    <?php } ?>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                      <?php $p++; ?>
                                                    @endforeach
                                             @endif
                                               
                                        </tbody>
                                    </table>
                                    
                                       <!-- Modal -->
                              <div class="modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">
                                
                                  <!-- Modal content-->
                                   <form class="add_selected_tag_injson"  method="post" action="{{url('api/new-add-custom-tag')}}">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      <h4 class="modal-title">New Custom Tags</h4>
                                    </div>
                                    <div class="modal-body">
                                       
                                      <? if($category == 'professional'){ ?>
                                      <input type="hidden" value="{{$subcategory}}" name="{{$subcategory}}" >
                                      <? }else{ ?>
                                        <input type="hidden" value="{{$subcategory}}" name="{{$category}}">
                                      <? } ?>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Custom Tag</label>
                                            <input type="text" required class="form-control" id="tagnamecu" name="custagvalue" placeholder="#tag"   >
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                  </div>
                                  </form>
                                </div>
                              </div>
                                    
                                    <!-- Modal -->
                                        <div id="updateModal" class="modal fade" role="dialog">
                                          <div class="modal-dialog">
                                            <form id="updatetagform" method="post" action="{{url('api/update-custom-tags')}}">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Update Tag</h4>
                                              </div>
                                              <div class="modal-body">
                                                  <? if($category == 'professional'){ ?>
                                                  <input type="hidden" value="{{$subcategory}}" name="categoryname" >
                                                  <? }else{ ?>
                                                   <input type="hidden" value="{{$category}}" name="categoryname" >
                                                  <? } ?>
                                                  <input type="hidden" value="{{$subcategory}}" name="subcategoryname" >
                                                  <input type="hidden" name="previous_tag" value="" id="tagId">
                                                  <input type="hidden" name="previous_tag_index" id="tagindexid">
                                                 <label> Tag Name: </label>
                                                 <input type="text" value="" name="newtagname" id="updatetagname" placeholder ="#tagname" required>
                                              </div>
                                              <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                
                                              </div>
                                            </div>
                                        </form>
                                          </div>
                                        </div>
                                        
                                         <!-- END EXAMPLE TABLE PORTLET-->
                                </div>
                            </div>
                           
                        </div>
                    </div>
                 </div>
                <!-- END CONTENT BODY -->
            </div>
           
  @endsection
  
