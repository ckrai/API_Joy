@extends('layouts.map-layout')
@section('content')
   <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <!-- BEGIN THEME PANEL -->
                  
                    <!-- END THEME PANEL -->
                    <!-- BEGIN PAGE BAR -->
     
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                  
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                              
                                <div class="portlet-title">
                                    <div class="col-md-6">
                                        <div class="caption font-dark">
                                            <i class="icon-settings font-dark"></i> 
                                             <span class="caption-subject bold uppercase">Sub Admins</span>
                                        </div>
                                   </div>
                                   <div class="col-md-6">
                                    <button type="button" class="btn sbold green pull-right" data-toggle="modal" data-target="#myModal"> <i class="fa fa-plus"></i>Add New</button>

                                  </div>
                                   
                                   
                                </div>
                                
                                
                                <div class="portlet-body">
                                  
                                     <p class="successresponce"></p>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>	
                                             
                        						<th>Email</th>
                        				 
                        						<th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=0; ?> 
                                            @foreach($users as $user)
                                             <tr>
                                                <td>{{++$i}}</td>
                                                <td> {{$user->name}} </td>
                                                  
                                                <td>{{$user->email}}</td>                        
                                             
                        						<td>
                         							<a href="{{url('delete-user/'.$user->id.'?admin=1')}}" onclick="return confirm('Are you sure?' )" class="delete" title="Delete" data-toggle="tooltip" style="color:red">X</a>
                        						</td>
                                            </tr>
                        				 @endforeach
                                        </tbody>
                                    </table>
                                    
                                 
                                </div>
                            </div>
                           
                        </div>
                    </div>
                 </div>
                <!-- END CONTENT BODY -->
            </div>
           <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add New Sub Admin</h4>
      </div>
      <div class="modal-body">


                    <form onsubmit="submitForm(this)" action="javascript::void(0)">
                      <div class="form-group">
                        <label for="email">Name:</label>
                        <input type="text" class="form-control" id="name">
                        <span class="error name_error"></span>
                      </div>
                      
                      <div class="form-group">
                        <label for="email">Email address:</label>
                        <input type="email" class="form-control" id="email">
                        <span class="error email_error"></span>
                      </div>
                      <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password">
                        <span class="error password_error"></span>
                      </div>
                       
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </form>




      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script>
     function submitForm(){
         var error =false;
        var name = $('#name').val();
        var email = $('#email').val();
        var password = $('#password').val();
        $('.error').text('');
         
         if(name=='' || typeof name === 'undefined'){
             $('.name_error').text('Please enter name');
             error=true;
         }
         if(email=='' || typeof email === 'undefined'){
             $('.email_error').text('please enter email');
             error=true;
         }
         
         if (email !='' && !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
          {
             $('.email_error').text('please enter valid email');
             error=true;
          }
  
         if(password=='' || typeof password === 'undefined'){
             $('.password_error').text('please enter password');
             error=true;
         }
         
         if(error){ return false;}
         
         
          var dataString = 'name='+ name + '&email=' + email + '&password=' + password;
           $.ajax({
            type: "POST",
            url: "{{url('api/add_sub_admin')}}",
            data: dataString,
            success: function(data) { 
                if(data.error_code=='200'){
                  alert('Sub Admin successfully added ')  ;
                  window.location.reload();
                 return false;   
                    
                }
                
                
                
                $.each(data, function (i) {
                    $('.'+i+'_error').text(data[i])
                    });
            }
          });
          
         
         
         
         
         
         
         
         
         
         
     }
    
</script>
<style>span.error {
    color: red;
}</style>
  @endsection
  
