<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Custom_tag;
use App\Feedback;
use App\Event;


use File;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
         $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        
        if(\Auth::user()->role=='0'){
            
            return $this->homeforAdmin();
        }
         if(\Auth::user()->role=='1'){
           return $this->homeforSubAdmin(); 
            
        }
        
        
    }
    
    
    
    
    function homeforAdmin(){  $folders=$this->folders();
         
         $data=[];
         $i=0;
         
         
         
         foreach($folders as $fkey=>$favls){
              $name=trim($fkey);
              $total=0; 
             if($name != 'professional'){
                 $gda=[];
                 $total=0;
                  foreach($favls as $v){
                  $gda[$v]=[ $v=>count($this->getFileAndFiles($fkey,$v))]    ;
                  $total=$total+count($this->getFileAndFiles($fkey,$v));
                  }
                 $data[$fkey] =['data'=>$gda, 'total'=>$total];
                 
             }else{
                  
                    
                 $gda=[];
                 $total=0;
                  foreach($favls as $v){
                  $gda[$v]=[ $v=>count($this->getFileAndFiles($v,$v))]    ;
                  $total=$total+count($this->getFileAndFiles($v,$v));
                  }
                 $data['professional'] =['data'=>$gda, 'total'=>$total]; 
                    
                    
                    
                        
                 
                 // $this->getFileAndFiles($cat,$file);
             }
            
         }
          
         
        $pagename = 'home'; 
         
         
        return view('home',compact( 'folders','data','pagename'));
    }
    
    function homeforSubAdmin(){
               
       $folders=$this->folders();
        $pagename = 'timeline';
         
              $events=[];
        if(\Auth::user()->role=='0'){
             $events=  Event::orderBy('time','desc')->get();
        }
         if(\Auth::user()->role=='1'){
             $events=  Event::where('user_id',\Auth::user()->id)->orderBy('time','desc')->get();
        }
         
        $AllEvents=[];
        foreach($events as $event){
      $date= date('Y-m-d',strtotime($event->time));
                    $edata['id']=$event->id;            
                    $edata['user_id']=$event->user_id;
                    $edata['title']=$event->title;
                    $edata['description']=$event->description;
                    $edata['time']=$event->time;
                    $edata['location']=$event->location;
                    $edata['lat']=$event->lat;
                    $edata['lan']=$event->lan;
                    $edata['image']=$event->image;
                    $edata['images']=$event->images;
                    $edata['created_at']=$event->created_at;
                    $edata['updated_at']=$event->updated_at; 
                            
                            
                            
            $AllEvents[$date][]=$edata;
        }
         
         
         
         
         
         
         
         
         
         
      return view('timeline',compact('folders','pagename','AllEvents'));  
    }
    
    
    
    
    
    
    function getFileAndFiles($cat,$file){
        
        return  json_decode(file_get_contents(public_path('json-data/'.$cat.'/'.$file.'.json')),JSON_FORCE_OBJECT);
        
        
    }
    
    
    
    
    
    
    
    
    
    public function users(){
             
        $folders=$this->folders();
        $pagename = 'users';
        $users=  User::where('role','2')->get();
      return view('users',compact('users','folders','pagename'));  
        
    }
    
   public function timeline(){
             
        $folders=$this->folders();
        $pagename = 'timeline';
        $events=[];
        if(\Auth::user()->role=='0'){
             $events=  Event::get();
        }
         if(\Auth::user()->role=='1'){
             $events=  Event::where('user_id',\Auth::user()->id)->get();
        }
         
        $AllEvents=[];
        foreach($events as $event){
      $date= date('Y-m-d',strtotime($event->time));
                    $edata['id']=$event->id;            
                    $edata['user_id']=$event->user_id;
                    $edata['title']=$event->title;
                    $edata['description']=$event->description;
                    $edata['time']=$event->time;
                    $edata['location']=$event->location;
                    $edata['lat']=$event->lat;
                    $edata['lan']=$event->lan;
                    $edata['image']=$event->image;
                    $edata['images']=$event->images;
                    $edata['created_at']=$event->created_at;
                    $edata['updated_at']=$event->updated_at;
                            
                            
                            
            $AllEvents[$date][]=$edata;
        }
         
      return view('timeline',compact('folders','pagename','AllEvents'));  
        
    }
    
    
       
    public function subAdmin(){
             
        $folders=$this->folders();
        $pagename = 'sub_admin';
        $users=  User::where('role','1')->get();
      return view('sub_admin',compact('users','folders','pagename'));  
        
    }
    
    
    
     public function events(){
        $folders=$this->folders();
        $pagename = 'events';
        
        if(\Auth::user()->role=='0'){
            
             $events=  Event::get();
        }
         if(\Auth::user()->role=='1'){
            $events=  Event::where('user_id',\Auth::user()->id)->get();
            
        }
       
       
       
      return view('events',compact('events','folders','pagename'));  
  
    }
    
      public function newEvent(){
        $folders=$this->folders();
        $pagename = 'events';
      return view('new-events',compact('folders','pagename'));  
  
    }
    
    
    
    
    
    
    
    public function feedbacks(){
             
     $folders=$this->folders();
          $pagename = 'feedbacks';
       $feedbacks=  Feedback::join('users', 'users.id', 'feedback.user_id')->select('feedback.*','users.username as username')->get();
      return view('feedbacks',compact('feedbacks','folders','pagename'));  
        
    }
    
    
   public function DeleteUser($id){
       $users=  User::where('id',$id)-> delete();
       
       if(isset($_REQUEST['admin'])&& $_REQUEST['admin']==1){
            return redirect('sub-admin');
           
       }else{
           return redirect('users');
       }
       
   }  
   public function Custom(){
       $pagename = 'Custom';
        $ORDERBY="custom_tags.custom_tag";
        $ORDER="ASC";
        
        if(isset($_REQUEST['order_by']) && $_REQUEST['order_by'] !=''){
            
            if($_REQUEST['order_by']=='custom_tag'){ $ORDERBY='custom_tags.custom_tag';}
            if($_REQUEST['order_by']=='column'){ $ORDERBY='custom_tags.column';}
            if($_REQUEST['order_by']=='username'){ $ORDERBY='users.username';}
            if($_REQUEST['order_by']=='created_at'){ $ORDERBY='custom_tags.created_at';}
        }
         if(isset($_REQUEST['order']) && $_REQUEST['order'] !=''){
            $ORDER=$_REQUEST['order'];
         }
        $custom=  Custom_tag::join('users','users.id','custom_tags.user_id')->select('custom_tags.*','users.username as username')->orderBy($ORDERBY,$ORDER)->paginate(20);
        return view('custom_tags',compact('custom','pagename'));  
        //return view('custom_tags');
   }  
   
   public function declineCustomtag ($id){
      Custom_tag::where('id',$id)->update(['declined'=>1]); 
        return redirect('custom_tags');
   }
    public function adeclineCustomtag ($id){
      Custom_tag::where('id',$id)->update(['declined'=>1]); 
        return redirect('custom-tags-management');
   }
  function approveCustomtag($tagname,$filename){
    // $tagname . ' '. $filename;
     $tag =  '#'. $tagname;   
     $getfile = public_path('json/'.$filename.'.json');
     $data =  json_decode(file_get_contents(public_path('json/'.$filename.'.json')));

    array_push($data,$tag);
     $newjson = json_encode($data );
    $file = fopen($getfile,"w");
     fwrite($file,$newjson);
    fclose($file);
      //echo '<pre>';  print_r($data );echo '</pre>';
      $deleted =  Custom_tag::where('custom_tag',$tag)->delete();
       return redirect('custom_tags');
   }  
  
 public function categories($category='about_me' ,$subcategory='character_traits'){
    
           $folders=$this->folders();
           $pagename = 'categories/'.$category . '/'.$subcategory;
            //$pagename = 'categories';
     return view('categories',compact('folders','category','subcategory','pagename'));
     
 }

    public function customtagsmanagement($category='about_me' ,$subcategory='character_traits'){
        $pagename = 'customtagsmanagement';
        $ORDERBY="custom_tags.custom_tag";
        $ORDER="ASC";
        
        if(isset($_REQUEST['order_by']) && $_REQUEST['order_by'] !=''){
            
            if($_REQUEST['order_by']=='custom_tag'){ $ORDERBY='custom_tags.custom_tag';}
            if($_REQUEST['order_by']=='column'){ $ORDERBY='custom_tags.column';}
            if($_REQUEST['order_by']=='username'){ $ORDERBY='users.username';}
            if($_REQUEST['order_by']=='created_at'){ $ORDERBY='custom_tags.created_at';}
        }
         if(isset($_REQUEST['order']) && $_REQUEST['order'] !=''){
            $ORDER=$_REQUEST['order'];
         }
        $custom=  Custom_tag::join('users','users.id','custom_tags.user_id')->select('custom_tags.*','users.username as username')->groupBy('custom_tags.custom_tag')->get();
        $folders=$this->folders();
       // print_r($custom);
       // die();
        
        return view('customtagsmanagement',compact('custom','folders','category','subcategory','pagename'));  
     }
    
    
    
   
    
    
    
    public function folders(){
     return     [
            'about_me'=>[
               'character_traits',
               'disabilities',
               'nationality',
               'other',
               'personality_types',
               'philosophy',
               'politics',
               'relationships',
               'religion'
                ],
            'animal_lover'=>[
                'celebrity_pets',
                'imaginary_animals',
                'pets',
                'wild_animals'
                ],
            'entertainment'=>[
                'authors',
                'book_genre',
                'books',
                'genre',
                'misc',
                'movies',
                'music_act',
                'music_genre',
                'podcast',
                'podcast_creator',
                'podcast_genres',
                'standup_comedians',
                'streaming_service_original_content',
                'tv_shows'
                
                ],
            'food_drink'=>[
                'brands',
                'drinks',
                'etc',
                'food',
                'influencer',
                'lifestyle',
                'places'
                
                ],
            'fitness_and_hobbies'=>[
                'console_games',
                'hobbies',
                'phone_games',
                'sports'
                
                ],
            'travel_and_places'=>[
                'cities',
                'countries',
                'environments',
                'general_places',
                'parks_beaches',
                'specific_places_brands'
                ],
            'professional'=>[
                        'job_title',
                        'company',
                        'work_extra_skills',
                        'colleges',
                        'major',
                        'education_extra_skill'
                ]
         ];
        
        
        
        
    }
    
    
    
    public function deletetagbyname($cat,$subcat,$tagname){
       // echo $cat . ' ' . $subcat. ' '. $tagname;
         $getfile = public_path('json-data/'.$cat.'/'.$subcat.'.json');
         //print_r( $getfile);exit;
         $data =  json_decode(file_get_contents(public_path('json-data/'.$cat.'/'.$subcat.'.json')),JSON_FORCE_OBJECT);
       
        //echo '<pre>';  print_r($data );echo '</pre>';exit;
        foreach($data as $key => $value){
            $tagv = ltrim($value, '#');
            if($tagv == $tagname){
                //$index$key;
                unset($data[$key]); 
            }
        }
        $arr = array_values($data );
        
        $newjson = json_encode($arr );
        $file = fopen($getfile,"w");
         fwrite($file,$newjson);
        fclose($file);
       
         return redirect('categories/'.$cat.'/'.$subcat);
    }
    
}
