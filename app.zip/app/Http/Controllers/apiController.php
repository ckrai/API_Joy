<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Validator;
use App\User;
use Auth;
use App\Friend;


class apiController extends Controller
{
        public function userRegister(Request $request){
                try {
                    $data=$request->input();
                   
                     $validator = Validator::make($request->input(), [
                    'name' => 'required|max:255'
                     ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'Name invalid ']); }
                     
                     $validator = Validator::make($request->input(), [
                        'email' => 'required|string|email|max:255|unique:users'
                   
                     ]);
                    if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'Email invalid or already exists']); }

                     $validator = Validator::make($request->input(), [
                       'phone' => 'required|string|min:10'
                     ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'invalid phone  number']); }
                     
                     $validator = Validator::make($request->input(), [
                          'password' => 'required|string|min:8'
                        ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'invalid password']); }
                    
                    $name=$data['name'];
                    $email=$data['email'];
                    $password=$data['password'];
                    $phone=$data['phone'];
                    $token=Hash::make($password).$data['phone'];
                    User::create(['name'=>$name , 'email'=>$email , 'password'=>Hash::make($password) ,'role'=>'1','phone'=>$phone,'_token'=>$token ])  ;  
                    return response()->json(['error_code'=>'200', "error_message" => 'Successfully Added']); 
                } catch (\Exception $e) {
                         return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
                 
                }
        }

 
     

            public function userLogin(Request $request)
                    {
                        $user_id = $error_message = $error_code = $token = '';
                        $email = $request->input('email');
                        $password = $request->input('password');
                        $user=[];
                        $auth_token= Hash::make(time().'-'.mt_rand());
                        if(isset($email) && isset($password))
                            {
                	                    if(Auth::attempt(['email' => $email, 'password' => $password]))
                                            { 
                                                $user= Auth::user();
                                                $user_id = $user->id;
                                                if($user->_token==null || $user->_token==''){ User::where('id',$user->id)->update(['_token'=>Hash::make($user->email).mt_rand(100000, 999999)]) ;  }
                                                $user= User::where('id',$user->id)->first();
                                                $error_code = "200";
                                                $error_message = "User loggedin.";
                                            }
                                            else
                                            {
                                                $error_code = "201";
                                                $error_message = "Invalid email or password.";
                                            }
                                    
                            }
                        else
                            {
                                $error_message = "invalid data.";
                                $error_code = "201";
                            }
                        return response()->json(['error_code'=>$error_code, "error_message" => $error_message, "user_id" => $user_id,  'data'=>$user]);
             }
     
        function updateProfilePic(Request $request){
                $user=$this->verifyToken($request->header('_token'));
                 if(!isset($user->id)){  
                        return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
                 }
                 try {
                         $error_code='200';
                         $error_message='';
                        $fileName = null;
                        if (request()->hasFile('profile_pic')) {
                            $file = request()->file('profile_pic');
                            $fileName = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                            $file->move('./uploads/profile_pic/', $fileName);
                             User::where('id',$user->id)->update(['profile_pic'=>$fileName]);
                            $user=User::where('id',$user->id)->first();
                        }else{
                            $error_code='204';
                             $error_message='Please select an image file';
                        }
                     return response()->json(['error_code'=>$error_code, "error_message" => $error_message,  'data'=>$user]);
                    } catch (\Exception $e) {
                           return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
                    }
           }
           
          function updateProfile(Request $request){
                $user=$this->verifyToken($request->header('_token'));
                 if(!isset($user->id)){  
                        return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
                 }
                 try {
                     
                     $data=$request->input();
                   
                         $validator = Validator::make($request->input(), [
                        'name' => 'required|max:255'
                         ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'Name invalid ']); }
                     
                         $validator = Validator::make($request->input(), [
                            'email' => 'required|string|email|max:255'
                       
                         ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'Email invalid ']); }

                     if($data['email']!=''){
                                $checkEmail=User::where('id','!=',$user->id)->where('email',$data['email'])->first();
                                if(isset($checkEmail->id)){
                                   return response()->json(['error_code'=>'201', "error_message" => 'Email already used by some other user']);
                                }
                      }

                         $validator = Validator::make($request->input(), [
                           'phone' => 'required|string|min:10'
                         ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'invalid phone  number']); }
                     
                          $validator = Validator::make($request->input(), [
                           'gender' => 'required|string'
                         ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'invalid gender']); }
                       
                     
                         $validator = Validator::make($request->input(), [
                           'city' => 'required|string'
                         ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'invalid city']); }
                       
                         $validator = Validator::make($request->input(), [
                           'address' => 'required|string'
                         ]);
                     if ($validator->fails()) { return response()->json(['error_code'=>'201', "error_message" => 'invalid address']); }
                       
                            $name=$data['name'];
                            $email=$data['email'];
                            $phone=$data['phone'];
                            $gender=$data['gender'];
                            $city=$data['city'];
                            $address=$data['address'];
                     User::where('id',$user->id)->update(['name'=>$name , 'email'=>$email , 'phone'=>$phone,'gender'=>$gender,'city'=>$city,'address'=>$address ])  ;  
                    return response()->json(['error_code'=>'200', "error_message" => 'Successfully updated']); 
                 } catch (\Exception $e) {
                           return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
                    }
           }
    
    
       
        public function friendSearch(Request $request){
            $data=$request->input();
            $user=$this->verifyToken($request->header('_token'));
            if(!isset($user->id)){  
            return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
            }
            
            try {
               $myFriends=[];
                $friends= Friend::where(function ($query) use ($user) {
                    $query->where('send_from',$user->id)
                          ->orWhere('send_to',$user->id);
                })->where('status','1');
                foreach($friends as $f){$myFriends[]=$f->id;}
                 $myFriends[]=$user->id;
                 $keyword= isset($data['keyword'])?$data['keyword']:'';
                 $data= User::whereNotIn('id', $myFriends) ->Where('name', 'like', '%' .$keyword. '%')->select('id','profile_pic','name','address','gender')->get();
                 return response()->json(['error_code'=>'200', 'error_message' => '','data'=>$data]);
            }
            catch (\Exception $e) {
                 return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
            }
      }
        public function friendRequestSend(Request $request){
            $data=$request->input();
            $user=$this->verifyToken($request->header('_token'));
            if(!isset($user->id)){  
            return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
            }
            try {
                $send_from=$user->id;
                $send_to=$data['friend_id'];
                Friend::create(['send_from'=>$send_from,'send_to'=>$send_to]);
                return response()->json(['error_code'=>'200', 'error_message' => 'Successfully sends']);
            }
            catch (\Exception $e) {
                 return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
            }
       }
      
       public function friendRequestListToAccept(Request $request){
            $data=$request->input();
            $user=$this->verifyToken($request->header('_token'));
            if(!isset($user->id)){  
            return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
            }
            try {
                $friends=[];
                $friendsLists=Friend::where('send_to',$user->id)->where('status','0')->get();
                foreach($friendsLists as $list){
                         $user=   User::where('id',$list->send_from)->first();
                        
                     $list->profile_pic=$user->profile_pic;
                     $list->name=$user->name;
                     $list->address=$user->address;
                     $list->gender=$user->gender;
                    $friends[]= $list;
                }
                return response()->json(['error_code'=>'200', 'error_message' => '','friends'=>$friends]);
            }
            catch (\Exception $e) {
                 return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
            }
        }
        
        public function friendRequestAcceptDecline(Request $request){
            $data=$request->input();
            $user=$this->verifyToken($request->header('_token'));
            if(!isset($user->id)){  
            return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
            }
            
            try {
                $id=$data['list_id'];
                $status=$data['status'];    
                $friends=Friend::where('id',$id)->update(['status'=>$status]);
                return response()->json(['error_code'=>'200', 'error_message' => '']);
            }
            catch (\Exception $e) {
                 return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
            }
       }
        
        
        
        public function friendList(Request $request){
            $data=$request->input();
            $user=$this->verifyToken($request->header('_token'));
            if(!isset($user->id)){  
            return response()->json(['error_code'=>'201', "error_message" => 'please enter valid user token']); 
            }
             
            try {
               $friendsLists= Friend::where(function ($query) use ($user) {
                    $query->where('send_from',$user->id)
                          ->orWhere('send_to',$user->id);
                })->where('status','1')->get();
            
               $friends=[];
                foreach($friendsLists as $list){
                      $uid='';
                     if( $user->id != $list->send_to){ $uid= $list->send_to;  }
                     if( $user->id != $list->send_from){ $uid= $list->send_from;  }
                         $u=   User::where('id',$uid)->first();
                        
                         $list->profile_pic=$u->profile_pic;
                         $list->name=$u->name;
                         $list->address=$u->address;
                         $list->gender=$u->gender;
                         $friends[]= $list;
                }
                 return response()->json(['error_code'=>'200', 'error_message' => '','friends'=>$friends]);
            }
            catch (\Exception $e) {
                 return response()->json(['error_code'=>'204', "error_message" => $e->getMessage()]);
            }
        }











public function verifyToken($token=''){
      try {
          $user= User::where('_token',$token)->first();
                return $user;

        } catch (\Exception $e) {
               return ['error_code'=>'204', "error_message" => $e->getMessage()];
         
        }
}

    
    
    
    
     
    
      
    
    
        
     
    
    
   
    
}