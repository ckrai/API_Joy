<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

  

//Auth::routes();
// Route::get('/', 'HomeController@index');
// Route::get('/home', 'HomeController@index');
// Route::get('/users', 'HomeController@users');
// Route::get('/delete-user/{id}', 'HomeController@DeleteUser');
// Route::get('/custom_tags', 'HomeController@Custom');
// Route::get('/approve-custom-tag/{id}/{file}', 'HomeController@approveCustomtag');
// Route::get('/decline-custom-tag/{id}', 'HomeController@declineCustomtag');
// Route::get('/adecline-custom-tag/{id}', 'HomeController@adeclineCustomtag');
// Route::get('/categories/{category}/{subcategory}', 'HomeController@categories');
// Route::get('/categories', 'HomeController@categories');
// Route::get('/custom-tags-management', 'HomeController@customtagsmanagement');
// Route::get('/delete-tag/{category}/{subcategory}/{tagname}', 'HomeController@deletetagbyname');
// Route::get('/delete-user/{id}', 'HomeController@DeleteUser');

// Route::get('/feedbacks', 'HomeController@feedbacks');
// Route::get('/sub-admin', 'HomeController@subAdmin');
// Route::get('/timeline', 'HomeController@timeline');

 
// Route::get('/events', 'HomeController@events');
// Route::get('/new-event', 'HomeController@newEvent');


// Route::get('/logout', 'Auth\LoginController@logout');
